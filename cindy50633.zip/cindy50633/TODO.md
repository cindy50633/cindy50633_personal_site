# TODO

This is a TODO list for the feature/zend-mvc-v3-minimal branch.

## Documentation

- ModuleRouteListener is removed from the skeleton. This won't affect existing
  users, but *will* affect experienced users who originally relied on it being
  active in new skeleton projects.
- The `/[:controller][/:action]]` route was removed from the skeleton. Again, it
  will not affect existing users, but *will* affect experienced users who
  originally relied on it being active in new skeleton projects.
